Google Chrome / Firefox extension to override some of MouseHunt's browser CSS with a darker, more comfortable color palette

Chrome Web Store link:

https://chrome.google.com/webstore/detail/mousehunt-dark-mode/mpplmgighfandgidhocpmnegnpckioah

Firefox Add-Ons link:

https://addons.mozilla.org/en-US/firefox/addon/mousehunt-dark-mode/
